produtos = []
vendas = []
